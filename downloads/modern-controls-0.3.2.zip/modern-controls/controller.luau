--!nonstrict
-- Keep gameplay's aim + melee wrench throw. Menu input is left entirely native.
local M = {}
local layout = require("layout")
function M.setup(state)
    local throw_reported = false
    omni.on_pad(function(port, report)
        if port ~= 0 or state.wheel then return end
        local mode = omni.mode()
        local down = bit32.band(bit32.bnot(bit32.bor(bit32.lshift(buffer.readu8(report, 0), 8), buffer.readu8(report, 1))), 0xFFFF)
        if mode == "gameplay" then
            if omni.setting("aim_wrench_throw") == false or bit32.band(down, 0x80) == 0 then return end
            local base = layout.hero()
            -- The native camera has consumed the physical aim button before on_pad.
            -- The physical aim action stays separate from camera-directed hip fire.
            if not base or omni.read("u8", base + 0x20a4) ~= 0 or not layout.aim_held(base) then return end
            -- Let the original game perform Comet Strike (R1 + Square), including
            -- its wind-up, release, hit checks and return. Preserve other pressures.
            down = bit32.bor(down, 8)
            local released = bit32.band(bit32.bnot(down), 0xFFFF)
            buffer.writeu8(report, 0, bit32.rshift(released, 8))
            buffer.writeu8(report, 1, bit32.band(released, 0xFF))
            buffer.writeu8(report, 15, 255)
            if not throw_reported then
                throw_reported = true
                omni.log("aim + melee routed to native wrench throw")
            end
            return
        end
    end)
end
return M
