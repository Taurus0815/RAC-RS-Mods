# Rift Modern 0.13.0

**Ersteller / Author: Taurus0815**

## Deutsch

**Neu in 0.13.0:** Abgestimmt auf RAC-RS 0.5.1. Titel-, Pause-, Optionen-, Händler- und Dialogmenüs verwenden wieder vollständig die Originalansicht und Originalsteuerung. Nur das Schnellmenü pausiert das Spiel und zeigt die Waffenbilder.

Die vorherigen Änderungen an Menüoptik und Controller-Zurück-Taste sind entfernt. Ziel-/Nahkampf-Wurf, Schultersteuerung, HUD und Bewegung bleiben verfügbar.

Rift-Apart-inspiriertes HUD und reaktionsschnellere Steuerung für RAC-RS 0.5.1. Benötigt OmniLoader 0.1.0, Host-ABI 1.6 und Script-API 1.3. Geprüft auf PAL SCES-50916 v1.00.

- Originale Kollision, Bodenphysik und Waffenabläufe bleiben erhalten.
- Zweimal kurz Zielen antippen: Schulteransicht mit seitlicher/rückwärtiger Bewegung ein-/ausschalten. Normales Halten bleibt temporäres Zielen.
- Zielen halten + Viereck/X: nativer Schraubschlüsselwurf (Comet Strike, mit den ursprünglichen Aktionsbedingungen). Viereck allein bleibt normaler Nahkampf; Sprung-/Aufschlagaktionen laufen weiter nativ.
- Kompaktes pausiertes Schnellwahlrad mit farbigen Waffen-/Gadget-Bildern. Die originale Haltezeit und erste Dreieck-Eingabe bleiben für Händler und andere Interaktionen erhalten.
- Alle anderen Spielmenüs und ihre Controller-Steuerung bleiben original. Geschwindigkeit, Aufschlag-Radien und Bolt-Anziehung sind in den Mod-Optionen regelbar.

### Installation

Den vollständigen Ordner `rift-modern` mit `main.luau`, `omni-mod.json`, `mod.json`, `images` und `textures` nach `mods` kopieren. Vorher vorhandene Dateien sichern und die Mod im Launcher aktivieren.

RAC-RS 0.5.1 stellt die nativen Funktionen für Schulterbewegung und das pausierte Schnellwahlrad bereit. Die Bilder sind Teil dieser Mod; die ZIP installiert keinen Player. Mit HQ Texture Remake zusammen muss Rift Modern in der Aktivliste davor stehen.

J schaltet die Bewegungsreaktion um und K das HUD. Diese Tasten sind frei belegbar. Die Wurfkombination folgt den eingestellten Ziel- und Nahkampf-Aktionen; sie schreibt keine Launcher-Belegung um. Die Option `Aim + melee: wrench throw` kann separat ausgeschaltet werden.

Die Gesundheitsanzeige verwendet standardmäßig die originale Spielgesundheit. Ein optionaler externer Modus ist für eine separat vorhandene, kompatible Nanotech-HUD-Integration gedacht. Arsenal Mastery wird nicht mitgeliefert. Bereits gespeicherte persönliche Werte bleiben erhalten.

## English

**New in 0.13.0:** Matched to RAC-RS 0.5.1. Title, pause, options, vendor and dialog menus use their original appearance and controls again. Only Quick Select pauses the game and displays weapon pictures.

The previous menu styling and controller Back remap have been removed. Aim/melee wrench throw, shoulder controls, HUD and movement remain available.

Rift Apart-inspired HUD and more responsive controls for RAC-RS 0.5.1. Requires OmniLoader 0.1.0, host ABI 1.6 and script API 1.3. Checked on PAL SCES-50916 v1.00.

- Native collision, ground physics and weapon routines are retained.
- Double-tap aim to toggle shoulder framing with sideways/backward movement. Holding aim normally remains temporary aiming.
- Hold aim + press Square/X for the native Comet Strike wrench throw, subject to the original action conditions. Melee alone remains normal melee; jumping and ground impacts keep their native paths.
- Compact paused Quick Select wheel with full-colour weapon/gadget pictures. The original hold delay and initial Triangle input remain available for vendors and other interactions.
- All other game menus and their controller controls remain original. Animation speeds, impact radii and bolt attraction are adjustable in the mod settings.

### Installation

Copy the complete `rift-modern` folder, including `main.luau`, `omni-mod.json`, `mod.json`, `images` and `textures`, into `mods`. Back up existing files and enable the mod in the launcher.

RAC-RS 0.5.1 provides the native features for shoulder locomotion and the paused Quick Select wheel. The pictures are included in this mod; the ZIP does not install a player. When used with HQ Texture Remake, place Rift Modern above it in the active list.

J toggles movement response and K toggles the HUD. These keys are configurable. The wrench combo follows the configured aim and melee actions and does not overwrite launcher bindings. `Aim + melee: wrench throw` can be disabled separately.

Health rendering defaults to the original game's health. An optional external mode is intended for a separately installed compatible Nanotech HUD integration. Arsenal Mastery is not bundled. Existing personal settings are preserved.

## Downloads und Bilder / Downloads and pictures

[ZIP-Pakete und Vorschauen / ZIP packages and previews](https://github.com/Taurus0815/RAC-RS-Mods)

## Lizenz / License

Die Script-Dateien stehen unter der beiliegenden MIT-Lizenz. Waffenbilder sind aus der lokalen Disc gerenderte Spielgrafiken; die MIT-Lizenz der Scripts gilt nicht für diese Grafiken. Verarbeitung und Prüfsummen: `picture-receipt.json`.

Scripts use the included MIT license. Weapon pictures are game graphics rendered from the local disc; the script license does not apply to those graphics. Processing details and checksums: `picture-receipt.json`.
