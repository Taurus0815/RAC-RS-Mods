--!nonstrict
-- Pause the native Quick Select while keeping the game's original wheel art.
local M = {}
local layout = require("layout")
local pause_view = require("pause_view")
local cx, cy = 128, 208
local pressure = { 0x2000, 0x8000, 0x1000, 0x4000, 0x10, 0x20, 0x40, 0x80, 4, 8, 1, 2 }

local function buttons(report)
    return bit32.band(bit32.bnot(bit32.bor(bit32.lshift(buffer.readu8(report, 0), 8), buffer.readu8(report, 1))), 0xffff)
end

local function set(report, down)
    local released = bit32.band(bit32.bnot(down), 0xffff)
    buffer.writeu8(report, 0, bit32.rshift(released, 8))
    buffer.writeu8(report, 1, bit32.band(released, 255))
    for i = 2, 5 do buffer.writeu8(report, i, 128) end
    for i, mask in ipairs(pressure) do
        buffer.writeu8(report, 5 + i, bit32.band(down, mask) ~= 0 and 255 or 0)
    end
end

local function entries(base)
    local slots, count = {}, 0
    for i = 0, 7 do
        local id = omni.read("i32", base + 0x2b50 + i * 4)
        if type(id) ~= "number" or id < 0 or id > 36 then return nil end
        slots[i + 1] = id
        if id > 1 then count += 1 end
    end
    return count > 0 and slots or nil
end

local function choose(wheel, x, y)
    if x * x + y * y < 1600 then return end
    local sector = (math.floor(math.atan2(x, -y) / (math.pi / 4) + 0.5) % 8) + 1
    if wheel.slots[sector] > 1 then wheel.selected = sector end
end

function M.setup(state)
    local previous, consumed, warned = false, false, false
    local native_ready

    if omni.has("rac1.omni.weapon.quick_select") then
        omni.after("rac1.omni.weapon.quick_select", function(element)
            if element < 0x100000 or element >= 0x2000000 then native_ready = nil; return end
            if not omni.setting("pause_quick_select") then native_ready = nil; return end
            local fade = omni.read("u8", element + 0x70)
            if not state.wheel and not consumed and omni.mode() == "gameplay" then
                native_ready = fade >= 8 and { element = element, level = omni.level() } or nil
            else
                native_ready = nil
            end
        end)
    end

    if omni.has("rac1.omni.vendor.open") then
        omni.after("rac1.omni.vendor.open", function()
            native_ready = nil
            if not state.wheel then consumed = true end
        end)
    end

    local function pad(port, report)
        if port ~= 0 then return end
        local down = buttons(report)
        local held = bit32.band(down, 0x10) ~= 0
        local mode = omni.mode()
        local wheel = state.wheel
        if not held then native_ready = nil; consumed = false end

        if not wheel and consumed and held then
            local released = bit32.band(bit32.bnot(bit32.band(down, 0xffef)), 0xffff)
            buffer.writeu8(report, 0, bit32.rshift(released, 8))
            buffer.writeu8(report, 1, bit32.band(released, 255))
            buffer.writeu8(report, 10, 0)
            previous = held
            return
        end

        -- Let the game's contextual Triangle action and opening delay win first.
        if not wheel and not consumed and held and previous and native_ready
            and native_ready.level == omni.level() and omni.setting("pause_quick_select")
            and mode == "gameplay" then
            local base = layout.hero()
            local slots = base and entries(base) or nil
            if base and slots and omni.read("u8", base + 0x20a4) == 0 then
                local selected = 1
                local equipped = omni.fields.omni.weapon.equipped
                for i, id in ipairs(slots) do
                    if id == equipped then selected = i; break elseif id > 1 then selected = i end
                end
                wheel = {
                    phase = "opening", age = 0, slots = slots, selected = selected,
                    base = base, element = native_ready.element, level = omni.level(),
                    request = false, resume = 0,
                }
                state.wheel = wheel
                if pause_view.begin(wheel) then
                    consumed = true
                    native_ready = nil
                    omni.log("native Quick Select pause opening")
                    set(report, 0x800)
                else
                    state.wheel = nil
                end
            end
        elseif wheel then
            if mode ~= "pause" and mode ~= "gameplay" then
                pause_view.restore(wheel); state.wheel = nil; previous = held; return
            end
            if not held or bit32.band(down, 0x801) ~= 0 then
                wheel.cancel = wheel.cancel or bit32.band(down, 0x801) ~= 0
                wheel.closing = true
            end
            choose(wheel, buffer.readu8(report, 4) - 128, buffer.readu8(report, 5) - 128)
            if bit32.band(down, 0x1000) ~= 0 then choose(wheel, 0, -127)
            elseif bit32.band(down, 0x2000) ~= 0 then choose(wheel, 127, 0)
            elseif bit32.band(down, 0x4000) ~= 0 then choose(wheel, 0, 127)
            elseif bit32.band(down, 0x8000) ~= 0 then choose(wheel, -127, 0) end
            local out = 0
            if wheel.resume > 0 then out = 0x800; wheel.resume -= 1 end
            set(report, out)
        end
        previous = held
    end

    omni.on_pad(function(port, report)
        local ok, err = pcall(pad, port, report)
        if not ok then
            pause_view.restore(state.wheel)
            state.wheel = nil
            if not warned then warned = true; omni.warn("Quick Select pause input failed: " .. tostring(err)) end
        end
    end)

    local function frame()
        pause_view.scan()
        local wheel = state.wheel
        if not wheel then return end
        local mode = omni.mode()
        wheel.age += 1
        if mode == "pause" and omni.pause_page() == "root" then
            pause_view.hide(wheel)
            if wheel.phase == "opening" then
                wheel.phase = "active"
                wheel.pause_age = 0
                omni.log("Quick Select paused; native wheel retained")
            end
            wheel.pause_age += 1
            if wheel.element and wheel.level == omni.level()
                and wheel.element >= 0x100000 and wheel.element < 0x2000000 then
                -- Finish the native fade so the unmodified game wheel stays readable.
                omni.write("u8", wheel.element + 0x70, 16)
            end
            local ok, p, q, inside = pcall(omni.pointer)
            if ok then
                local x, y = p, q
                if type(p) == "table" then x, y, inside = p.x or p[1], p.y or p[2], p.inside or p[3] end
                if type(x) == "number" and type(y) == "number" and (inside == true or inside == 1) then
                    if wheel.px and wheel.pause_age > 6 and math.abs(x - wheel.px) + math.abs(y - wheel.py) > 2 then
                        choose(wheel, x - cx, y - cy)
                    end
                    wheel.px, wheel.py = x, y
                end
            end
            if wheel.closing and wheel.pause_age >= 35 and not wheel.request then
                local base = layout.hero()
                local id = wheel.slots[wheel.selected]
                if not wheel.cancel and base == wheel.base and id > 1 then
                    omni.write("i32", base + 0x20b8, id)
                    wheel.expected = id
                end
                wheel.request = true
                wheel.resume = 3
            end
        elseif mode == "gameplay" and wheel.phase == "active" and wheel.request then
            pause_view.restore(wheel)
            omni.log("Quick Select resumed: requested=" .. tostring(wheel.expected)
                .. ", equipped=" .. tostring(omni.fields.omni.weapon.equipped))
            state.wheel = nil
        elseif wheel.age > 180 and wheel.phase == "opening" then
            pause_view.restore(wheel)
            state.wheel = nil
            omni.warn("Quick Select pause did not open; original controls restored")
        elseif mode ~= "gameplay" and mode ~= "pause" then
            pause_view.restore(wheel)
            state.wheel = nil
        end
    end

    omni.on_frame(function()
        local ok, err = pcall(frame)
        if not ok then
            pause_view.restore(state.wheel)
            state.wheel = nil
            if not warned then warned = true; omni.warn("Quick Select pause failed: " .. tostring(err)) end
        end
    end)
end

return M
