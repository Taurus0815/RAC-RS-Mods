# Rift Modern 0.14.0

**Ersteller / Author: Taurus0815**

## Deutsch

**Neu in 0.14.0:** Das Standard-HUD und die Originalmenüs bleiben aktiv. Rift Modern blendet sein eigenes HUD standardmäßig aus. Zweimal kurz die Aim-Taste drücken, um Anvisieren ein- oder auszuschalten; gedrückt halten bleibt normales temporäres Zielen. Im Schnellrad werden die originalen Waffen-/Gadget-Bilder aus dem Quick-Select-Art verwendet, nicht die kleinen Munitionssymbole.

- Das Schnellrad pausiert weiterhin das Spiel und übernimmt die Auswahl beim Loslassen.
- Originale Controller-Belegung des Launchers und andere Menüs bleiben unangetastet.
- Bewegung, Schraubenschlüssel, Aufschlag und Bolt-Anziehung bleiben einstellbar.
- Das Rift-HUD kann in den Mod-Einstellungen ausdrücklich eingeschaltet werden; im Preset „Rift Modern“ bleibt es aus.

RAC-RS 0.5.1, OmniLoader 0.1.0, Host-ABI 1.6 und Script-API 1.3. Geprüft auf PAL SCES-50916 v1.00.

### Installation

Den vollständigen Ordner `rift-modern` mit `main.luau`, `omni-mod.json`, `mod.json`, `images` und `textures` nach `mods` kopieren und die Mod im Launcher aktivieren. Vorhandene Dateien vorher sichern. Mit HQ Texture Remake zusammen Rift Modern in der Aktivliste davor setzen.

## English

**New in 0.14.0:** The standard HUD and original menus remain active. Rift Modern's own HUD is off by default. Double-tap the Aim button to toggle aiming; holding it remains temporary aim. The wheel now uses the game's original Quick Select weapon/gadget artwork instead of the small ammo symbols.

- The Quick Select wheel still pauses the game and commits the selection on release.
- Launcher controller bindings and other menus remain untouched.
- Movement, wrench, overhead impact and bolt attraction remain configurable.
- The Rift HUD can be explicitly enabled in mod settings; it stays off in the “Rift Modern” preset.

RAC-RS 0.5.1, OmniLoader 0.1.0, host ABI 1.6 and script API 1.3. Checked on PAL SCES-50916 v1.00.

### Installation

Copy the complete `rift-modern` folder, including `main.luau`, `omni-mod.json`, `mod.json`, `images` and `textures`, to `mods`, then enable it in the launcher. Back up existing files first. When used with HQ Texture Remake, place Rift Modern above it in the active list.

## Downloads / Downloads

[ZIP and previews](https://github.com/Taurus0815/RAC-RS-Mods)

## License

Scripts use the included MIT license. Weapon picture provenance and checksums are in `picture-receipt.json`.
