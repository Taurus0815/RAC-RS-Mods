--!nonstrict
-- RAC-RS 0.5.1 routes the controller Aim action through the standard R2 pad bit.
-- Double short taps toggle that native Aim input; a sustained press remains hold-to-aim.
local M={}
local AIM=0x0002
local AIM_PRESSURE=17

local function buttons(report)
    return bit32.band(bit32.bnot(bit32.bor(bit32.lshift(buffer.readu8(report,0),8),buffer.readu8(report,1))),0xffff)
end

local function write_aim(report,down)
    local held=buttons(report)
    held=down and bit32.bor(held,AIM) or bit32.band(held,bit32.bnot(AIM))
    local released=bit32.band(bit32.bnot(held),0xffff)
    buffer.writeu8(report,0,bit32.rshift(released,8))
    buffer.writeu8(report,1,bit32.band(released,0xff))
    buffer.writeu8(report,AIM_PRESSURE,down and 255 or 0)
end

function M.setup()
    local hz=omni.ticks_per_second and omni.ticks_per_second() or 50
    local tap_ticks=math.floor(hz*0.25+0.5)
    local gap_ticks=math.floor(hz*0.38+0.5)
    local tick,pressed_at,first_tap=0,nil,nil
    local previous_physical,second_tap,latched=false,false,false
    local reported=false

    omni.on_pad(function(port,report)
        if port~=0 then return end
        tick+=1
        if omni.mode()~="gameplay" or omni.setting("walk_shoulder")==false then
            previous_physical=false
            pressed_at=nil
            first_tap=nil
            second_tap=false
            return
        end

        local physical=bit32.band(buttons(report),AIM)~=0
        if first_tap and tick-first_tap>gap_ticks then first_tap=nil end
        if physical and not previous_physical then
            second_tap=first_tap~=nil and tick-first_tap<=gap_ticks
            pressed_at=tick
        elseif not physical and previous_physical then
            local short=pressed_at~=nil and tick-pressed_at<=tap_ticks
            if short and second_tap then
                latched=not latched
                first_tap=nil
                omni.log("double-tap Aim toggle: "..tostring(latched))
            elseif short then
                first_tap=tick
            else
                first_tap=nil
            end
            pressed_at=nil
            second_tap=false
        end

        previous_physical=physical
        -- Suppress short taps so they only arm the toggle; normal held aiming starts after the tap window.
        local sustained=physical and pressed_at~=nil and tick-pressed_at>tap_ticks
        write_aim(report,latched or sustained)
        if not reported then
            reported=true
            omni.log("Aim toggle ready on RAC-RS 0.5.1; double short taps latch native aim, sustained hold aims normally")
        end
    end)
end
return M
